var mongoose = require('./mongoose.js')

var Schema = mongoose.Schema

var userSchema = new Schema({
    /*设计用户数据--文档格式*/
    username:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    },
    /*是否为管理员*/
    isAdmin:{
        type:Boolean,
        default:false/*默认为普通用户*/
    },
    /**性别：1为男、0为女 */
    gender:{
        type:Number
    }
})
/*注意：集合命名为大写单数User，最终集合名会变为小写复数users*/
// var User = mongoose.model('User',userSchema)
module.exports = userSchema
