/*1、引包*/
var mongoose = require('mongoose')
// mongoose.set('useFindAndModify', false)
// mongoose.set('useNewUrlParser',true )
// mongoose.set('useUnifiedTopology',true )

var db_url = 'mongodb://localhost/blogDemo'
/*2、连接数据库*/
/*mongoose.connect('mongodb://localhost:27017/blogDemo')默认开启的端口为27017*/
mongoose.connect(db_url)/*这里也可以将端口去掉，默认便是27017*/
/* 链接成功 */
mongoose.connection.on('connected', function() {
  console.log('Mongoose connection open to ' + db_url);
});
/* 链接异常 */
mongoose.connection.on('error', function(error) {
  console.log('Mongoose connection error:' + error);
});
/* 链接断开 */
mongoose.connection.on('disconnected', function() {
  console.log('Mongoose connection disconnected');
});

module.exports = mongoose;
