var mongoose = require('./mongoose.js')

var Schema = mongoose.Schema
/*博客分类的表结构*/
var blogContentSchema = new Schema({
    /*设计用户数据--文档格式*/
    title:String,
    /*
        关联字段：分类id
        关联字段：和另一个数据表的数据关联（博客分类数据表的ObjectId，可以由数据库可视化工具查看）
    */
    sort:{
        type:mongoose.Schema.Types.ObjectId,/*类型：引用类型*/
        ref:'BlogSort'/*引用，关联上另外一个模型BlogSort博客分类模型*/
    },
    /*关联字段：用户id*/
    user:{
        type:mongoose.Schema.Types.ObjectId,/*类型：引用类型*/
        ref:'User'/*引用，关联上另外一个模型BlogSort博客分类模型*/
    },
    /*添加时间*/
    time:{
        type:Date,
        default:new Date()/*或者Date.now都是当前时间*/
    },
    /*阅读数*/
    views:{
        type:Number,
        default:0
    },
    /*评论*/
    comments:{
        type:Array,
        defauly:[]
    },
    description:{
        type:String,
        default:'暂无文章简介，可以点击详情查看文章具体内容'
    },
    content:{
        type:String,
        default:'文章具体内容... ...（默认值）'
    }
})
/*注意：集合命名为大写单数User，最终集合名会变为小写复数users*/
// var blogContentSchema = mongoose.model('User',blogContentSchema)
module.exports = blogContentSchema
