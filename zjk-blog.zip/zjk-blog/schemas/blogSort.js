var mongoose = require('./mongoose.js')

var Schema = mongoose.Schema
/*博客分类的表结构*/
var blogSortSchema = new Schema({
    /*设计用户数据--文档格式*/
    blogSortName:{
        type:String,
        required:true
    }
})
/*注意：集合命名为大写单数User，最终集合名会变为小写复数users*/
// var BlogSort = mongoose.model('User',blogSortSchema)
module.exports = blogSortSchema
