/*加载express模块*/
var express = require('express')
/*加载path路径处理核心模块*/
var path = require('path')
/*加载body-parser中间件*/
var bodyParser = require('body-parser')
/*加载cookie模块*/
var Cookies = require('cookies')
/*引入用户数据模型，用于判断用户类型是否管理员*/
var User = require('./models/User')
/*创建app应用 => 类似于Node.js原始的http.createServer()*/
var app = express()
/*定义端口号*/
var port = 3000
/*
    开放静态资源，开发时建议使用“动态绝对路径”
    path核心模块+__driname非模块成员
*/
app.use('/public',express.static(path.join(__dirname,'./public')))
app.use('/node_modules',express.static(path.join(__dirname,'./node_modules')))
/*配置模板引擎*/
/*1、定义当前应用使用的模板引擎。参数1：模板引擎名称，同时也是模板文件的后缀；参数2：用于解析处理模板内容的“方法”*/
app.engine('html', require('express-art-template'));
/*2、设置模板文件存放目录。参数1：必须是views；参数2：views目录路径*/
app.set('views','./public/views')
/*3、注册模板引擎，将之前定义的模板引擎配置到应用中。
    参数1：必须是view engine；参数2：必须是第1步里定义的模板引擎名称即html*/
app.set('view engine','html')
/*body-parser中间件配置*/
app.use(bodyParser.urlencoded({extended:true}))
app.use(bodyParser.json())
/*配置cookie*/
app.use(function(req,res,next){
    /*1、创建cookies对象，将cookies方法加载到req对象上*/
    req.cookies = new Cookies(req,res) 
    /*2、获取cookie--解析登录用户的cookie信息 */
    var userCookieInfo = {}
    if(req.cookies.get('userCookieInfo')){
        /*var baseInfo = new Buffer(req.cookies.get('userCookieInfo'), 'base64').toString()
        console.log(baseInfo)*/
        try{
            req.userCookieInfo = JSON.parse(req.cookies.get('userCookieInfo'))
            /*获取当前登录用户类型，判断是否是管理员*/
            User.findOne({
                username:req.userCookieInfo.username
            },function(error,data){
                req.userCookieInfo.isAdmin = Boolean(data.isAdmin)
                next()
            })
        }catch(error){}
    }else{
        next()/*交出请求执行权，往下匹配*/
    }
})

/*引入模板引擎，注册一个过滤器 通过处理时间戳 转为日期格式（start）*/
var template = require('art-template')
/**
 * 时间戳格式化方法
 * @param date
 * @param format
 * @returns {void | string}
 */
template.defaults.imports.dateFormat = function(date, format) {
    date = new Date(date);
    var map = {
        "M": date.getMonth() + 1, //月份
        "d": date.getDate(), //日
        "h": date.getHours(), //小时
        "m": date.getMinutes(), //分
        "s": date.getSeconds(), //秒
        "q": Math.floor((date.getMonth() + 3) / 3), //季度
        "S": date.getMilliseconds() //毫秒
    };
    format = format.replace(/([yMdhmsqS])+/g, function (all, t) {
        var v = map[t];
        if (v !== undefined) {
            if (all.length > 1) {
                v = '0' + v;
                v = v.substr(v.length - 2);
            }
            return v;
        } else if (t === 'y') {
            return (date.getFullYear() + '').substr(4 - all.length);
        }
        return all;
    });
    return format;
};
/*注册一个过滤器 通过处理时间戳 转为日期格式（END）*/

/*根据不同的功能划分路由模块--挂载路由实例*/
app.use('/admin',require('./router/admin'))/*后台管理*/
app.use('/api',require('./router/api'))/*api调用*/
app.use('/',require('./router/main'))/*前台展示*/
/*
    首页
    req→require请求
    res→response响应
    next→方法，执行下一个中间件
app.get('/',function(req,res,next){
    // res.send('<h1>欢迎来到我的博客</h1>')
    读取views目录下的指定文件，解析并返回给客户端
        参数1：模板文件相对于views目录的路径;参数2：传递给模板使用的数据
    res.render('index',{
        message:'你好，我是后端传递的数据'
    })
})
*/
/*配置404中间件*/
app.use(function(req,res,next){
    res.render('./main/404.html')
})
/*全局错误处理中间件*/
app.use(function(error,req,res,next){
    console.log('服务器错误'+error)
    return res.status(500).json({
        code:500,
        message:'服务端错误server error...'
    })
})
/*监听端口并启动*/
app.listen(port,function(){
    console.log('Server is running at port'+port)
})
