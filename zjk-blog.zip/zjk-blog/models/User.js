var mongoose = require('mongoose')
var userSchema = require('../schemas/users.js')
/*注意：集合命名为大写单数User，最终集合名会变为小写复数users*/
var User = mongoose.model('User',userSchema)
module.exports = User