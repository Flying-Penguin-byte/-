var express = require('express')
var router = express.Router();/*创建路由对象*/
/*引入User模型，基于模型进行数据库操作*/
var User = require('../models/User')
/*引入博客内容模型*/
var BlogContent = require('../models/BlogContent.js')
/*引入md5加密依赖包*/
var md5 = require('blueimp-md5')
/*统一返回响应格式*/
var responseData
router.use(function(req,res,next){
    responseData = {
        code:null,/*0代表无任何错误*/
        message:null/*错误返回提示信息*/
    }
    next()
})
/*处理用户注册*/
router.post('/user/register',function(req,res,next){
    var body = req.body
    var username = body.username
    var password = body.password
    var gender = body.gender
    var confirmPassword = body.confirmPassword
    /*正则匹配不能为空*/
    var regAir = /^\s*$/g
    if(regAir.test(username) || regAir.test(password)){
        responseData.code = 1/*自定义状态码*/
        responseData.message = '用户名或密码不能为空'
        return res.status(200).json(responseData)/*转为json，返回客户端*/
    }
    if(password !== confirmPassword){
        responseData.code = 2/*自定义状态码*/
        responseData.message = '两次输入的密码不一致'
        return res.status(200).json(responseData)
    }
    /*数据库查询验证*/
    User.findOne({
        username:username
    },function(error,data){
        if(error){
            return next(error)/*全局错误处理中间件*/
        }
        if(data){
            responseData.code = 3/*自定义状态码*/
            responseData.message = '该用户名已经存在'
            return res.status(200).json(responseData)
        }
        /*数据存储*/
        new User({
            username:username,
            isAdmin:true,
            gender:gender,
            password:md5(md5(password))/*密码md5加密存储*/
        }).save(function(error,data){
            if(error){
                return next(error)/*全局错误处理中间件*/
            }
            responseData.code = 0/*自定义状态码*/
            responseData.message = '注册成功'
            return res.status(200).json(responseData)
        })
    })
})
/*处理用户登录*/
router.post('/user/login',function(req,res,next){
    var body = req.body
    var username = body.username
    var password = body.password
    /*正则匹配不能为空*/
    var regAir = /^\s*$/g
    if(regAir.test(username) || regAir.test(password)){
        responseData.code = 1/*自定义状态码*/
        responseData.message = '用户名或密码不能为空'
        return res.status(200).json(responseData)/*转为json，返回客户端*/
    }
    /*数据库验证*/
    User.findOne({
        username:username,
        password:md5(md5(password))
    },function(error,data){
        if(error){
            next(error)/*全局错误处理中间件*/
        }
        if(!data){
            responseData.code = 2/*自定义状态码*/
            responseData.message = '用户名或密码错误'
            return res.status(200).json(responseData)/*转为json，返回客户端*/
        }
        responseData.code = 0/*自定义状态码*/
        responseData.message = '登录成功'
        var date_now = Date.now()+7*24*60*60*1000
        responseData.date_now = date_now
        responseData.userInfo = body/*返回用户信息，用于客户端信息展示*/
        /*登录成功，发送cookie到客户端*/
        req.cookies.set('userCookieInfo',JSON.stringify({
            username:username,
            id:data._id
            /*cookie不支持中文，所以转码
            username:new Buffer(username).toString('base64')
            */
        }))
        return res.status(200).json(responseData)
    })
})
/*处理用户退出*/
router.get('/user/logout',function(req,res,next){
    /*
        1、清除登录状态
        2、重定向到首页
    */
    console.log('退出')
    req.cookies.set('userCookieInfo',null)/*将userCookieInfo的cookie设为空*/
    res.redirect('/login')/*重定向到首页*/
})
/*处理用户提交评论*/
router.post('/user/comments',function(req,res,next){
    /*简单验证*/
    /*正则匹配不能为空*/
    var regAir = /^\s*$/g
    if(regAir.test(req.body.content)){
        responseData.code = 1/*自定义状态码*/
        responseData.message = '评论内容不能为空'
        return res.status(200).json(responseData)
    }
    var articleId = req.body.articleId || ''/*评论所属文章id*/
    var commentData = {
        username:req.userCookieInfo.username,/*评论人，直接根据cookie获取*/
        time:new Date(),/*评论时间*/
        content:req.body.content/*评论内容*/
    }
    /*查询当前评论所属文章内容*/
    BlogContent.findOne({
        _id:articleId
    },function(error,blogContentData){
        if(error){
            next(error)
        }
        /*将评论内容加到文章里comment评论数组末尾*/
        blogContentData.comments.unshift(commentData)
        /*持久化存储*/
        blogContentData.save()
        /*返回响应*/
        responseData.code = 0/*自定义状态码*/
        responseData.message = '评论成功'
        responseData.commentData = commentData
        return res.status(200).json(responseData)
    })
})
/*分页读取评论*/
router.get('/getAllComments',function(req,res,next){
    var articleId = req.query.articleId || ''/*评论所属文章id*/
    BlogContent.findOne({
        _id:articleId
    }).then(function(allComments){
        responseData.allComments = allComments
        return res.status(200).json(responseData)
    }).catch(function(error){
        next(error)
    })
})
module.exports = router
