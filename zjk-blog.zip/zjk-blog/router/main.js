var express = require('express')
var router = express.Router();/*创建路由对象*/
/*导入博客分类模型*/
var BlogSort = require('../models/BlogSort')
/*导入博客内容模型*/
var BlogContent = require('../models/BlogContent')
/*统一返回响应格式*/
var responseData
router.use(function(req,res,next){
    responseData = {
        code:null,/*0代表无任何错误*/
        message:null/*错误返回提示信息*/
    }
    next()
})
/*定义对象变量*/
var globalData
/*
    处理通用数据
    万能中间件--获取文章分类、用户信息等... ...
*/
router.use(function(req,res,next){
    /*全局对象初始化*/
    globalData = {
        userCookieInfo:req.userCookieInfo,/*登录信息*/
        blogSortList:[],/*博客分类*/
    }
    /*博客分类读取*/
    BlogSort.find().sort({_id:1}).then(function(sortData){
        globalData.blogSortList = sortData
        next()
    })
    
})
/*登录页渲染*/
router.get('/login',function(req,res,next){
    res.render('main/login.html')
})
/*注册页渲染*/
router.get('/register',function(req,res,next){
    res.render('main/register.html')
})
/*忘记密码页渲染*/
router.get('/forgetPassword',function(req,res,next){
    res.render('main/forgetPassword.html')
})
/*首页渲染*/
router.get('/',function(req,res,next){
    globalData.blogContentList = []
    globalData.page = parseInt(req.query.page) || 1/*当前页*/
    globalData.limit_number = 6/*限制数*/
    globalData.pages = 0/*总页数*/
    globalData.skpi_number = 0/*忽略数*/
    globalData.blogSortId = req.query.blogSortId || ''/*博客分类渲染-分类下分页*/
    /*博客分类渲染*/
    var _where = {}
    if(req.query.blogSortId){
        _where.sort = req.query.blogSortId
    }
    /*sort({_id:1})按照升序、sort({_id:-1})按照降序*/
    BlogSort.find().sort({_id:1})/*博客分类*/
        .then(function(sortData){
            
            return BlogContent.count().where(_where)/*博客数量，限制页数*/
        }).then(function(blogCount){
            globalData.pages = Math.ceil(blogCount/globalData.limit_number)/*计算总页数，向上取整*/
            /*页数限制，不能超过总页数*/
            globalData.page = Math.min(globalData.page,globalData.pages)
            /*页数限制，不能小于1*/
            globalData.page = Math.max(globalData.page,1)
            /*将忽略数，转移到page限制后面*/
            globalData.skpi_number = (globalData.page-1)*globalData.limit_number
            return BlogContent.where(_where).find()
                .sort({_id:-1}).populate('user')
                .limit(globalData.limit_number).skip(globalData.skpi_number)/*博客内容*/
        }).then(function(blogData){
            globalData.blogContentList = blogData
            res.render('main/index.html',globalData)/*html后缀可以省略*/
        }).catch(function(error){
            next(error)
        })
})
/*文章详情渲染*/
router.get('/view',function(req,res,next){
    var blogContentId = req.query.blogContentId || ''/*文章_id*/
    BlogContent.findOne({
        '_id':blogContentId
    }).populate('user').then(function(blogContentInfo){
        blogContentInfo.views+=1/*阅读数递增*/
        blogContentInfo.save()/*保存阅读数*/
        globalData.blogContentInfo = blogContentInfo
        res.render('main/view.html',globalData)
    })
})
module.exports = router
