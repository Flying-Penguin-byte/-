var express = require('express')
var router = express.Router();/*创建路由对象*/
/*引入用户数据模型*/
var User = require('../models/User.js')
/*引入博客分类模型*/
var BlogSort = require('../models/blogSort.js')
/*引入博客内容模型*/
var BlogContent = require('../models/BlogContent.js')
/*万能中间件：验证用户身份*/
router.use(function(req,res,next){
    /*console.log(req.userCookieInfo)*/
    if(!req.userCookieInfo.isAdmin){
        return res.send('对不起，普通用户无法登录... ...')
    }
    next()
})
/*统一返回响应格式*/
var responseData
router.use(function(req,res,next){
    responseData = {
        code:null,/*0代表无任何错误*/
        message:null/*错误返回提示信息*/
    }
    next()
})
/*后台管理首页*/
router.get('/',function(req,res,next){
    res.render('admin/index.html',{
        userCookieInfo:req.userCookieInfo
    })
})
/*用户管理*/
router.get('/user',function(req,res,next){
    /*
        查询数据库用户数据
        limit：限制读取的条数
        skip：忽略数据读取的条数
    */
    var page = req.query.page || 1/*当前页*/
    var limit_number = 6/*限制数*/
    var pages = 0/*总页数*/
    /*查询数据库文档数量*/
    User.count(function(error,user_number){
        if(error){
            next(error)/*全局错误处理中间件*/
        }
        pages = Math.ceil(user_number/limit_number)/*计算总页数，向上取整*/
        /*页数限制，不能超过总页数*/
        page = Math.min(page,pages)
        /*页数限制，不能小于1*/
        page = Math.max(page,1)
        /*将忽略数，转移到page限制后面*/
        var skpi_number = (page-1)*limit_number
        User.find(function(error,data){
            if(error){
                next(error)/*全局错误处理中间件*/
            }
            res.render('admin/userList.html',{
                userCookieInfo:req.userCookieInfo,
                userList:data,
                now_page:parseInt(page),
                user_number:user_number,
                pages:pages,
                limit_number:limit_number
            })
        }).limit(limit_number).skip(skpi_number).sort({
            _id:-1/*-1为降序*/
        })
    })  
})
/*博客分类管理*/
router.get('/blogSort',function(req,res,next){
    BlogSort.find(function(error,data){
        if(error){
            next(error)/*全局错误处理中间件*/
        }
        res.render('admin/blogSort.html',{
            userCookieInfo:req.userCookieInfo,
            blogSortList:data/*分类列表*/
        })
    }).sort({
        _id:-1/*-1为降序*/
    })
})
/*博客管理-添加博客分类-渲染*/
router.get('/blogSort/addBlogSort',function(req,res,next){
    res.render('admin/addBlogSort.html',{
        userCookieInfo:req.userCookieInfo
    })
})
/*博客管理-添加博客分类-处理*/
router.post('/blogSort/addBlogSort',function(req,res,next){
    var body = req.body
    var blogSortName = body.blogSortName
    /*正则匹配不能为空*/
    var regAir = /^\s*$/g
    /*简单验证*/
    if(regAir.test(body.blogSortName)){
        responseData.code = 1/*自定义状态码*/
        responseData.message = '分类名称不能为空'
        return res.status(200).json(responseData)/*转为json，返回客户端*/
    }
    /*数据库验证*/
    BlogSort.findOne({
        blogSortName:blogSortName
    },function(error,data){
        if(error){
            next(error)
        }
        if(data){
            responseData.code = 2/*自定义状态码*/
            responseData.message = '该分类已经存在'
            return res.status(200).json(responseData)
        }
        /*数据存储*/
        new BlogSort({
            blogSortName:blogSortName
        }).save(function(error,data){
            if(error){
                return next(error)/*全局错误处理中间件*/
            }
            responseData.code = 0/*自定义状态码*/
            responseData.message = '保存成功'
            return res.status(200).json(responseData)
        })
    })
})
/*编辑分类---展示
router.get('/blogSort/editBlogSort',function(req,res,next){
    if(req.query.blogSortName){
        responseData.code = 0 自定义状态码
        responseData.message = req.query.blogSortName
        return res.status(200).json(responseData)
    }
})
*/
/*编辑分类---处理*/
router.post('/blogSort/editBlogSort',function(req,res,next){
    var body = req.body
    var _id = body._id
    var blogSortName = body.blogSortName
    /*正则匹配不能为空*/
    var regAir = /^\s*$/g
    /*简单验证*/
    if(regAir.test(body.blogSortName)){
        responseData.code = 1/*自定义状态码*/
        responseData.message = '分类名称不能为空'
        return res.status(200).json(responseData)/*转为json，返回客户端*/
    }
    /*数据库验证*/
    BlogSort.findOne({
        _id:_id,
        blogSortName:blogSortName
    },function(error,data){
        if(error){
            next(error)
        }
        if(data){
            responseData.code = 2/*自定义状态码*/
            responseData.message = '该分类已经存在'
            return res.status(200).json(responseData)
        }
        /*更新数据的条件查询*/
        var update_id = _id
        /*执行更新数据*/
        var updateBlogSortName = {blogSortName:blogSortName}
        /*数据更新*/
        BlogSort.findByIdAndUpdate(update_id,updateBlogSortName,function(error,data){
            if(error){
                return next(error)/*全局错误处理中间件*/
            }
            responseData.code = 0/*自定义状态码*/
            responseData.message = '更新成功'
            responseData.newBlogSort = blogSortName
            return res.status(200).json(responseData)
        })
    })
})
/*删除分类-处理*/
router.post('/blogSort/deleteBlogSort',function(req,res,next){
    var body = req.body
    /*删除数据的条件*/
    var id = {'_id':body._id}
    /*删除数据*/
    BlogSort.remove(id,function(error,data){
        if(error){
            next(error)
        }
        responseData.code = 0/*自定义状态码*/
        responseData.message = '删除成功'
        return res.status(200).json(responseData)
    })
})
/*博客内容管理-首页*/
router.get('/blogContent',function(req,res,next){
    /*读取博客*/
    BlogContent.find().sort({'_id':-1}).populate(['user','sort'])
        .then(function(data){
            /*博客分类*/
            res.render('admin/blogContent.html',{
                userCookieInfo:req.userCookieInfo,
                blogContentList:data
            })            
        })
        .catch(function(error){
            next(error)
        })
})
/*添加博客内容--渲染*/
router.get('/blogContent/addBlogContent',function(req,res,next){
    /*查询博客分类*/
    BlogSort.find(function(error,data){
        if(error){
            next(error)
        }
        res.render('admin/addBlogContent.html',{
            userCookieInfo:req.userCookieInfo,
            blogSortList:data/*博客分类数据*/
        })
    }) 
})
/*添加博客内容--处理保存*/
router.post('/blogContent/addBlogContent',function(req,res,next){
    /*表单提交文章信息*/
    var title = req.body.title
    var description = req.body.description
    var sort = req.body.sort
    var content = req.body.content
    /*正则验证*/
    var regAir = /^\s*$/g
    if(regAir.test(title) || regAir.test(content)){
        responseData.code = 1/*自定义状态码*/
        responseData.message = '标题或内容不能为空'
        return res.status(200).json(responseData)/*转为json，返回客户端*/
    }
    /*数据存储*/
    new BlogContent({
        title:title,
        description:description,
        sort:sort,
        content:content,
        user:req.userCookieInfo.id.toString()/*当前登录用户的id*/
    }).save(function(error,data){
        if(error){
            return next(error)/*全局错误处理中间件*/
        }
        responseData.code = 0/*自定义状态码*/
        responseData.message = '保存成功'
        return res.status(200).json(responseData)
    })
})
/*编辑博客-渲染*/
router.get('/blogContent/edit',function(req,res,next){
    var id = req.query.id 
    /*查询博客内容*/
    BlogContent.findOne({'_id':id}).then(function(contentData){
        if(contentData){
            return contentData
        }else{
            responseData.code = 1/*自定义状态码*/
            responseData.message = '内容不存在'
            return res.status(200).json(responseData)
        }
    })
    .then(function(contentData){
        /*查询博客分类*/
        BlogSort.find().then(function(sortData){
            res.render('admin/editBlogContent.html',{
                userCookieInfo:req.userCookieInfo,
                blogContentList:contentData,/*将文章内容传回模板*/
                blogSortList:sortData/*将文章分类传回模板*/
            })
        }).catch(function(error){
            next(error)
        })
    })
    .catch(function(error){
        next(error)
    })
})
/*编辑博客--保存处理*/
router.post('/blogContent/edit',function(req,res,next){
    var body = req.body
    /*新数据*/
    var new_title = body.title
    var new_description = body.description
    var new_sort = body.sort
    var new_content = body.content
    /*简单数据验证*/
    /*正则验证*/
    var regAir = /^\s*$/g
    if(regAir.test(new_title) || regAir.test(new_content)){
        responseData.code = 1/*自定义状态码*/
        responseData.message = '标题或内容不能为空'
        return res.status(200).json(responseData)/*转为json，返回客户端*/
    }
    /*更新数据的条件查询*/
    var update_id = req.body._id
    /*执行更新数据*/
    var updateBlogContent = {
        /*表单提交文章信息*/
        'title':new_title,
        'description':new_description,
        'sort':new_sort,
        'content':new_content
    }
    /*数据更新*/
    BlogContent.updateOne({'_id':update_id},updateBlogContent,function(error,data){
        if(error){
            return next(error)/*全局错误处理中间件*/
        }
        responseData.code = 0/*自定义状态码*/
        responseData.message = '保存编辑成功'
        return res.status(200).json(responseData)
    })
})
/*删除博客*/
router.get('/blogContent/delete',function(req,res,next){
    /*删除数据的条件*/
    var delete_id = req.query._id
    /*删除数据*/
    BlogContent.remove({_id:delete_id},function(error,data){
        if(error){
            next(error)
        }
        responseData.code = 0/*自定义状态码*/
        responseData.message = '删除成功'
        return res.status(200).json(responseData)
    })
})
module.exports = router
