$(document).ready(function(){
    /*编辑模态框---渲染展示*/
    $('.editModalBtn').on('click',function(){
        var sortName = $(this).parent().prev().text()
        var _id = $(this).parent().prev().prev().text()
        /*改变自定义属性状态*/
        $(this).parent().prev().attr('data-status','1')
        $('input[name="blogSortName"]').val(sortName)
        $('input.edit_id').val(_id)
        $('.prompt-modal-edit').text('')
    })
    /*取消编辑*/
    $('#close-edit').on('click',function(){
        /*改变自定义属性状态*/
        $('td[data-status="1"]').attr('data-status','0')
    })
    /*编辑模态框---提交保存*/
    $('#editForm').on('submit',function(e){
        e.preventDefault()
        var formData = $(this).serialize()
        $.ajax({
            url:'/admin/blogSort/editBlogSort',
            type:'post',
            data:formData,
            dataType:'json',
            success:function(data){
                $('.prompt-modal-edit').text(data.message)
                /*成功后自动关闭模态框*/
                if(data.code == 0){
                    setTimeout(function(){
                        /*局部更新页面*/
                        $('td[data-status="1"]').text(data.newBlogSort).attr('data-status','0')
                        /*隐藏模态框*/
                        $('#editModal').modal('hide')
                    },1000)
                }
            }
        })
    })
    /*删除模态框--渲染*/
    $('.deleteModalBtn').on('click',function(){
        var sortName = $(this).parent().prev().text()
        var _id = $(this).parent().prev().prev().text()
        $('#delete-sort-name').text(sortName)
        $('input.edit_id').val(_id)
        /*改变自定义属性状态*/
        $(this).parent().prev().attr('data-status','1')
        $('.prompt-modal-edit').text('')
    })
    /*取消删除*/
    $('#close-delete').on('click',function(){
        /*改变自定义属性状态*/
        $('td[data-status="1"]').attr('data-status','0')
    })
    /*删除模态框--提交删除*/
    $('#deleteForm').on('submit',function(e){
        e.preventDefault()
        var formData = $(this).serialize()
        $.ajax({
            url:'/admin/blogSort/deleteBlogSort',
            type:'post',
            data:formData,
            dataType:'json',
            success:function(data){
                $('.prompt-modal-edit').text(data.message)
                /*成功后自动关闭模态框*/
                if(data.code == 0){
                    setTimeout(function(){
                        /*局部更新页面*/
                        $('td[data-status="1"]').attr('data-status','0').parent().remove()
                        /*隐藏模态框*/
                        $('#deleteModal').modal('hide')
                    },1000)
                }
            }
        })
    })
    /*添加博客内容*/
    $('#addBlogContent').on('submit',function(e){
        e.preventDefault()
        var formData = $(this).serialize()
        $.ajax({
            url:'/admin/blogContent/addBlogContent',
            type:'post',
            data:formData,
            dataType:'json',
            success:function(data){
                if(data.code != 0){
                    $('#add-content-prompt').show(100,function(){
                        $('#add-content-prompt').find('div').text(data.message)
                        setTimeout(function(){
                            $('#add-content-prompt').hide()
                        },3000)
                    })
                    return
                }
                $('#add-content-prompt').find('div').removeClass('alert alert-danger col-sm-10')
                    .addClass('alert alert-success col-sm-10').show().text(data.message)
                setTimeout(function(){
                    window.location.href = '/admin/blogContent'
                },2000)
            }
        })
    })
    /*编辑博客-提交*/
    $('#editBlogContent').on('submit',function(e){
        e.preventDefault()
        var formData = $(this).serialize()
        $.ajax({
            url:'/admin/blogContent/edit',
            type:'post',
            data:formData,
            dataType:'json',
            success:function(data){
                $('#edit-content-prompt').show().find('div').text(data.message)
                if(data.code == 0){
                    $('#edit-content-prompt').find('div').removeClass('alert alert-danger col-sm-10')
                        .addClass('alert alert-success col-sm-10').show().text(data.message)
                    setTimeout(function(){
                        window.location.href = '/admin/blogContent'
                    },2000)
                }
            }
        })
    })
    /*删除博客*/
    $('.delete_blog_btn').on('click',function(){
        var id_data = $(this).attr('data-id')
        var _this = $(this)
        $.ajax({
            url:'/admin/blogContent/delete',
            type:'get',
            data:{
                _id:id_data
            },
            dataType:'json',
            success:function(data){
                $('#content-prompt').show().find('div').text(data.message)
                if(data.code == 0){
                    $('#content-prompt').show().find('div')
                    .removeClass('alert alert-danger')
                    .addClass('alert alert-success')
                    .text(data.message)
                    setTimeout(function(){
                        _this.parent().parent().hide(300,function(){
                            _this.parent().parent().remove()
                        })
                        $('#content-prompt').hide()
                    },1000)
                }
            }
        })
    })
})